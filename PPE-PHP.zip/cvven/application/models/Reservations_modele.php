<?php

class Reservations_modele extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    public function getReserv_all() {
        $query = $this->db->get('reservation');
        return $query->result_array();
    }

    public function getReserv($numclient) {
        $query = $this->db->get_where('reservation', array('idClient' => $numclient));
        return $query->result_array();
    }

    public function set_form() {

        $data = array(
            'Date_Arrivee' => $this->input->post('Date_Arrivee'),
            'Date_Depart' => $this->input->post('Date_Depart'),
            'Nb_Personnes' => $this->input->post('Nb_Personnes'),
            'Menage' => $this->input->post('Menage'),
            'idClient' => $this->input->post('idClient'),
        );
        return $this->db->insert('reservation', $data);
    }

    public function set_form1() {

         $sql = ("UPDATE reservation "
                . "SET EtatReservation = '" . $this->input->post('EtatReservation') .
                "' WHERE idReserv = '" . $this->input->post('idReserv') . "'");
        $this->db->query($sql);
    }
    
    public function set_form2() {

        $sql = ("UPDATE reservation "
                . "SET Date_Arrivee = '" . $this->input->post('Date_Arrivee') .
                "', Date_Depart = '" . $this->input->post('Date_Depart') .
                "', Nb_Personnes = '" . $this->input->post('Nb_Personnes') .
                "', Menage = '" . $this->input->post('Menage') .
                "' WHERE idReserv = '" . $this->input->post('idReserv') . "'");
        $this->db->query($sql);
    }

    public function set_form3() {

        $sql = ("DELETE FROM reservation WHERE idReserv =".$this->input->post('idReserv')."");
        $this->db->query($sql);
    }
    
    public function set_form4() {

        $data = array(
            'Date_Arrivee' => $this->input->post('Date_Arrivee'),
            'Date_Depart' => $this->input->post('Date_Depart'),
            'Nb_Personnes' => $this->input->post('Nb_Personnes'),
            'Menage' => $this->input->post('Menage'),
            'idClient' => $this->input->post('idClient'),
        );
        return $this->db->insert('reservation', $data);
    }
    
}
