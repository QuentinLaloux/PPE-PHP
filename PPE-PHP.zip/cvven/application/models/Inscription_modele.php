<?php

class Inscription_modele extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    public function getInscri_all() {
        $query = $this->db->get('utilisateur');
        return $query->result_array();
    }

    public function set_form2() {

        $data = array(
            'login' => $this->input->post('login'),
            'mdp' => $this->input->post('mdp'),
            'nom' => $this->input->post('nom'),
            'prenom' => $this->input->post('prenom'),
        );
        return $this->db->insert('utilisateur', $data);
    }

}
