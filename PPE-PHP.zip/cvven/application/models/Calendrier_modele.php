<?php

class calendrier_modele extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    public function getReserv() {
        $query = $this->db->get('reservation');
        return $query->result_array();
    }

}
