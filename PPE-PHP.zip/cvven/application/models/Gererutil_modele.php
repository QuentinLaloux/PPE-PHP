<?php

class Gererutil_modele extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    public function getUtil_all() {
        $query = $this->db->get('utilisateur');
        return $query->result_array();
    }

    public function set_form() {

        $data = array(
            'login' => $this->input->post('login'),
            'mdp' => $this->input->post('mdp'),
            'nom' => $this->input->post('nom'),
            'prenom' => $this->input->post('prenom'),
            'admin' => $this->input->post('admin'),
        );
        return $this->db->insert('utilisateur', $data);
    }

    public function set_form2() {

        $sql = ("UPDATE utilisateur "
                . "SET login = '" . $this->input->post('login') .
                "', mdp = '" . $this->input->post('mdp') .
                "', nom = '" . $this->input->post('nom') .
                "', prenom = '" . $this->input->post('prenom') .
                "' WHERE idUtil = '" . $this->input->post('idUtil') . "'");
        $this->db->query($sql);
    }

    public function set_form3() {

        $sql = ("DELETE FROM utilisateur WHERE idUtil =".$this->input->post('idUtil')."");
        $this->db->query($sql);
    }
    
    public function set_form4() {

        $sql = ("UPDATE utilisateur "
                . "SET mdp = '" . $this->input->post('mdp') .
                "' WHERE login = '" . $this->input->post('login') . "'");
        $this->db->query($sql);
    }

}
