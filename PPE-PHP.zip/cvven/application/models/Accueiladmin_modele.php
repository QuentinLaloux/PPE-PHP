<?php

class Accueiladmin_modele extends CI_Model {

    public function __construct() {
        $this->load->database();
    }
    
    
}