<?php

class ConnexionUtilisateur_modele extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    public function getUtil() {
        $query = $this->db->get('utilisateur');
        return $query->result_array();
    }

    public function set_form1() {
        $sql = ("SELECT login,mdp FROM utilisateur WHERE login LIKE '"
                . $this->input->post('login') . "'AND mdp LIKE '"
                . $this->input->post('mdp') . "' ;");
        $this->db->query($sql);
    }

}
