<!-- Affichage du titre définis dasn le controleur --> 
<h1> <center><?php echo "$titre"; ?> </center> </h1>

<!-- Balise permettant de centrer --> 
<center>
    
<!-- Avec le foreach on passe en revue le tableau --> 
<?php foreach ($reserv as $reserv_item): ?>

    <!-- Balise permettant de sauter une ligne --> 
    <br>
    
    <!-- On affiche ce qui a été récupéré --> 
    <h3>
        Réservation numéro <?php echo $reserv_item['idReserv']; ?> 
    </h3>

    <p>Date d'arrivée </p>
    <h4>
        <?php echo $reserv_item['Date_Arrivee']; ?>
        <br>
    </h4>

    <p>Date de départ </p>
    <h4>
        <?php echo $reserv_item['Date_Depart']; ?>
        <br>
    </h4>

    <p>Nombre de personnes </p>
    <h4>
        <?php echo $reserv_item['Nb_Personnes']; ?>
        <br>
    </h4>

    <p>Menage </p>
    <h4>
        <?php echo $reserv_item['Menage']; ?>
        <br>
    </h4>

    <p>Etat de la réservation</p>
    <h4>
        <?php echo $reserv_item['EtatReservation']; ?>
        <br>
    </h4>

<?php endforeach; ?>
</center>