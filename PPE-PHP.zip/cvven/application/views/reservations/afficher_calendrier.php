<!-- Affichage du titre définis dasn le controleur --> 
<h1> <center><?php echo "$titre"; ?> </center> </h1>

<!-- Balise permettant de centrer --> 
<center>

    <!-- Balise permettant de sauter une ligne --> 
    <br>
    <br>

    <!-- Affichage dasn une balise php du calendrier --> 
    <?php
    echo $this->calendar->generate($this->uri->segment(3), $this->uri->segment(4));
    ?>

    <br>
    <br>

    <!-- Lien vers la vue affiche_all qui affiche toutes les réservations --> 
    <a href=<?php echo base_url('index.php/reservations/afficher_all'); ?>>Voir toutes les réservations</a>

</center>