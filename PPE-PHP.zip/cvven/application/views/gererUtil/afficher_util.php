<!-- Affichage du titre définis dasn le controleur --> 
<h1> <center><?php echo "$titre"; ?> </center> </h1>

<!-- Balise permettant de centrer --> 
<center>
    
<!-- Avec le foreach on passe en revue le tableau --> 
<?php foreach ($util as $util_item): ?>

    <!-- Balise permettant de sauter une ligne --> 
    <br>
    
    <!-- On affiche ce qui a été récupéré --> 
    <h3>
        Id Utilisateur <?php echo $util_item['idUtil']; ?> 
    </h3>

    <p>Login </p>
    <h4>
        <?php echo $util_item['login']; ?>
        <br>
    </h4>

    <p>Nom </p>
    <h4>
        <?php echo $util_item['nom']; ?>
        <br>
    </h4>

    <p>Prénom </p>
    <h4>
        <?php echo $util_item['prenom']; ?>
        <br>
    </h4>

<?php endforeach; ?>
</center>