<div style="text-align:center;margin-top:50px;font-family:arial;font-size:20px;">

    <html>
        <head>
            <meta charset="UTF-8">
            <link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/css/cssGeneral.css"); ?>">
            <link rel="icon" href="favicon.ico" />
            <title>Accueil</title>
        </head>
        <body>

            <img src="<?php echo base_url('assets/css/Logo.png'); ?>" alt="Logo CVVEN" />
            
            <p id="para1">
            Bienvenue sur le site de CVVEN
            </p>

            <ul id="menu-demo2">

                <li>
                    <a href=<?php echo base_url('index.php/ConnexionUtilisateur/connexion'); ?>>Connexion Utilisateur</a>
                </li>
                
                <li>
                    <a href=<?php echo base_url('index.php/ConnexionAdmin/connexion'); ?>>Connexion Administrateur</a>
                </li>
                
                <li>
                    <a href=<?php echo base_url('index.php/inscription/inscription'); ?>>Inscription</a>
                </li>

            </ul>

</div>