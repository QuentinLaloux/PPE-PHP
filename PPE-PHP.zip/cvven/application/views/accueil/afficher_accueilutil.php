<div style="text-align:center;margin-top:50px;font-family:arial;font-size:20px;">

    <html>
        <head>
            <meta charset="UTF-8">
            <link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/css/cssGeneral.css"); ?>">
            <title>Accueil</title>
        </head>
        <body>

            <img src="<?php echo base_url('assets/css/Logo.png'); ?>" alt="Logo CVVEN" />

            <p id="para1">
            Bienvenue dans votre espace utilisateur
            </p>
            
            <ul id="menu-demo2">

                <li><a href="">Réservation</a>
		<ul>
			<li><a href=<?php echo base_url('index.php/reservations/creation_reservationutil'); ?>>Prendre une réservation</a></li>
			<li><a href=<?php echo base_url('index.php/calendrier/afficher_calendrier'); ?>>Calendrier des réservations</a></li>
                        <li><a href="">Mes réservations</a></li>
		</ul>
                </li>
                
                <li><a href="">Mon compte</a>
		<ul>
			<li><a href=<?php echo base_url('index.php/GererUtil/modif_mdp_utilisateur'); ?>>Modification Mot de passe</a></li>
		</ul>
                </li>
                
                <li>
                    <a href="">Deconnexion</a>
                </li>

            </ul>

            </br>
            
</div>