<html>
    <head>
        <title>Formulaire de création d'une résevation utilisateur</title>
    </head>
    <body>

        <?php echo validation_errors(); ?>

        <?php echo form_open('reservations/creation_reservationutil'); ?>

        <h5>Date d'arrivée</h5>
        <input type="date" name="Date_Arrivee" value="<?php echo set_value('Date_Arrivee'); ?>" size="50" />

        <h5>Date de départ</h5>
        <input type="date" name="Date_Depart" value="<?php echo set_value('Date_Depart'); ?>" size="50" />

        <h5>Nombre de personnes</h5>
        <input type="number" name="Nb_Personnes" value="<?php echo set_value('Nb_Personnes'); ?>" size="50" />

        <h5>Ménage</h5>
        <input type="radio" name="Menage" value="Oui" /> Oui
        <br>
        <input type="radio" name="Menage" value="Non" /> Non

        <h5>ID d'utilisateur</h5>
        <input type="text" name="idClient" value="<?php echo set_value('idClient'); ?>" size="50" />

        <br><br><input type="submit" value="Envoyer" />

        <br><br><a href=<?php echo base_url('index.php/accueilutil/afficher_accueilutil'); ?>>Retourner à l'accueil</a>
    </form>

</body>
</html>