h2<?php echo $titre?></h2>

<?php echo validation_errors();?>

<?php echo form_open('reservations/form');?>

<label for="titre">Titre</label>
<input type="input" name="titre"/><br/>

<label for=""texte>Texte</label>
<textarea name=""texte></textarea><br/>

<input type="submit" name="submit" value="réserver !"/>

</form>

<?php>public function create()
{
    $this->load->helper('form');
    $this->load->library('form_validation');

    $data['title'] = 'Create a news item';

    $this->form_validation->set_rules('title', 'Title', 'required');
    $this->form_validation->set_rules('text', 'text', 'required');

    if ($this->form_validation->run() === FALSE)
    {
        $this->load->view('templates/header', $data);
        $this->load->view('news/create');
        $this->load->view('templates/footer');

    }
    else
    {
        $this->news_model->set_news();
        $this->load->view('news/success');
    }
}
?>
<?php
$this->form_validation->set_rules('username','Username','required');
$this->form_validation->set_rules('password','Password','required');
?>