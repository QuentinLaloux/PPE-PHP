<html>
    <head>
        <title>Formulaire de modification d'une réservation</title>
    </head>
    <body>

        <?php echo validation_errors(); ?>

        <?php echo form_open('reservations/modification_reservation'); ?>

        <h5>ID de la réservation</h5>
        <input type="int" name="idReserv" value="<?php echo set_value('idReserv'); ?>" size="50" />   

        <h5>Date d'arrivée</h5>
        <input type="text" name="Date_Arrivee" value="<?php echo set_value('Date_Arrivee'); ?>" size="50" />

        <h5>Date de départ</h5>
        <input type="text" name="Date_Depart" value="<?php echo set_value('Date_Depart'); ?>" size="50" />

        <h5>Nombre de personnes</h5>
        <input type="text" name="Nb_Personnes" value="<?php echo set_value('Nb_Personnes'); ?>" size="50" />

        <h5>Ménage</h5>
        <input type="text" name="Menage" value="<?php echo set_value('Menage'); ?>" size="50" />

        <br><br><input type="submit" value="Envoyer" />

        <br><br><a href=<?php echo base_url('index.php/accueiladmin/afficher_accueiladmin'); ?>>Retourner à l'accueil</a>
    </form>

</body>
</html>