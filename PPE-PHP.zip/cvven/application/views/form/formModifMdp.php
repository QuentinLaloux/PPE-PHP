<html>
    <head>
        <title>Formulaire de changement de mot de passe</title>
    </head>
    <body>

        <?php echo validation_errors(); ?>

        <?php echo form_open('GererUtil/modif_mdp_utilisateur'); ?>

        <h5>Nom d'utilisateur</h5>
        <input type="text" name="login" value="<?php echo set_value('login'); ?>" size="50" />

        <h5>Nouveau mot de passe</h5>
        <input type="text" name="mdp" value="<?php echo set_value('mdp'); ?>" size="50" />
        
        <h5>Confirmation nouveau mot de passe</h5>
        <input type="text" name="mdp" value="<?php echo set_value('mdp'); ?>" size="50" />
        

        <br><br><input type="submit" value="Valider" />

        <br><br><a href=<?php echo base_url('index.php/accueilutil/afficher_accueilutil'); ?>>Retourner à l'accueil</a>
    </form>

</body>
</html>