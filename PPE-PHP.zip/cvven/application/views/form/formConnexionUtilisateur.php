<html>
    <head>
        <title>Formulaire de connexion utilisateur</title>
    </head>
    <body>

        <?php echo validation_errors(); ?>

        <?php echo form_open('ConnexionUtilisateur/connexion'); ?>

        <h5>Login</h5>
        <input type="text" name="login" value="<?php echo set_value('login'); ?>" size="50" />

        <h5>Mot de passe</h5>
        <input type="password" name="mdp" value="<?php echo set_value('mdp'); ?>" size="50" />

        <br><br><input type="submit" value="Connexion" />
        <br><br><a href=<?php echo base_url('index.php/accueil/afficher_accueil'); ?>>Retourner à l'accueil</a>

    </form>

</body>
</html>