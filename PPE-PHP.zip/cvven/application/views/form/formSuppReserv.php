<html>
    <head>
        <title>Formulaire de suppression d'une réservation</title>
    </head>
    <body>

        <?php echo validation_errors(); ?>

        <?php echo form_open('reservations/suppression_reservation'); ?>

        <h5>ID de la réservation</h5>
        <input type="int" name="idReserv" value="<?php echo set_value('idReserv'); ?>" size="50" />   
        
        <br><br><input type="submit" value="Envoyer" />

        <br><br><a href=<?php echo base_url('index.php/accueiladmin/afficher_accueiladmin'); ?>>Retourner à l'accueil</a>
    </form>

</body>
</html>