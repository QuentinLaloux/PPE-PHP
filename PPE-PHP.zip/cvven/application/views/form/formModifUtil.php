<html>
    <head>
        <title>Formulaire de modification d'un utilisateur</title>
    </head>
    <body>

        <?php echo validation_errors(); ?>

        <?php echo form_open('GererUtil/modif_utilisateur'); ?>

        <h5>ID d'utilisateur</h5>
        <input type="int" name="idUtil" value="<?php echo set_value('idUtil'); ?>" size="50" />   

        <h5>Login</h5>
        <input type="text" name="login" value="<?php echo set_value('login'); ?>" size="50" />

        <h5>Mot de passe</h5>
        <input type="text" name="mdp" value="<?php echo set_value('mdp'); ?>" size="50" />

        <h5>Nom</h5>
        <input type="text" name="nom" value="<?php echo set_value('nom'); ?>" size="50" />

        <h5>Prénom</h5>
        <input type="text" name="prenom" value="<?php echo set_value('prenom'); ?>" size="50" />

        <h5>Administrateur</h5>
        <input type="radio" name="admin" value="Oui" /> Oui
        <br>
        <input type="radio" name="admin" value="Non" /> Non

        <br><br><input type="submit" value="Envoyer" />

        <br><br><a href=<?php echo base_url('index.php/accueiladmin/afficher_accueiladmin'); ?>>Retourner à l'accueil</a>
    </form>

</body>
</html>