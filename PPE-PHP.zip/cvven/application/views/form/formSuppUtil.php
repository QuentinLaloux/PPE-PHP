<html>
    <head>
        <title>Formulaire de suppression d'un utilisateur</title>
    </head>
    <body>

        <?php echo validation_errors(); ?>

        <?php echo form_open('GererUtil/supp_utilisateur'); ?>

        <h5>ID d'utilisateur</h5>
        <input type="int" name="idUtil" value="<?php echo set_value('idUtil'); ?>" size="50" />

        <br><br><input type="submit" value="Envoyer" />

        <br><br><a href=<?php echo base_url('index.php/accueiladmin/afficher_accueiladmin'); ?>>Retourner à l'accueil</a>
    </form>

</body>
</html>