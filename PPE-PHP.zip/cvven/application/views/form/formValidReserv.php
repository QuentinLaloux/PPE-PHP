<html>
    <head>
        <title>Formulaire de validation de réservation</title>
    </head>
    <body>

        <?php echo validation_errors(); ?>

        <?php echo form_open('reservations/validation_reservation'); ?>
        
        <h5>ID de la réservation</h5>
        <input type="text" name="idReserv" value="<?php echo set_value('idReserv'); ?>" size="50" />
        
        <h5>État de la réservation</h5>
        <input type="radio" name="EtatReservation" value="Faite" /> Faite
        <br>
        <input type="radio" name="EtatReservation" value="Non faite" /> Non faite

        <br><br><input type="submit" value="Envoyer" />

        <br><br><a href=<?php echo base_url('index.php/accueiladmin/afficher_accueiladmin'); ?>>Retourner à l'accueil</a>
    </form>

</body>
</html>