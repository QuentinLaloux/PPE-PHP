<html>
    <head>
        <title>Formulaire d'inscription</title>
    </head>
    <body>

        <?php echo validation_errors(); ?>

        <?php echo form_open('Inscription/inscription'); ?>

        <h5>Nom d'utilisateur</h5>
        <input type="text" name="login" value="<?php echo set_value('login'); ?>" size="50" />

        <h5>Nom</h5>
        <input type="text" name="nom" value="<?php echo set_value('nom'); ?>" size="50" />

        <h5>Prenom</h5>
        <input type="text" name="prenom" value="<?php echo set_value('prenom'); ?>" size="50" />
        
        <h5>Mot de passe</h5>
        <input type="text" name="mdp" value="<?php echo set_value('mdp'); ?>" size="50" />
        
        <h5>Confirmation mot de passe</h5>
        <input type="text" name="mdp" value="<?php echo set_value('mdp'); ?>" size="50" />

        <br><br><input type="submit" value="S'inscrire" />

        <br><br><a href=<?php echo base_url('index.php/accueil/afficher_accueil'); ?>>Retourner à l'accueil</a>
    </form>

</body>
</html>