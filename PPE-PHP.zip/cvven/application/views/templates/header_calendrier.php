<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF­8">
        <title> <?php echo $titre; ?></title>
    </head>
    <body>