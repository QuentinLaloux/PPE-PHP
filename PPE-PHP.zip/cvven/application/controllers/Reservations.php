<?php

Class Reservations extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('reservations_modele');
        $this->load->library('session');
    }

    /* Afficher toutes les réservations */

    public function afficher_all() {

        $data['titre'] = "Toutes les réservations";

        /* Chargement du modèle */
        $this->load->model('Reservations_modele');
        $data['reserv'] = $this->Reservations_modele->getReserv_all();

        /* Chargement de la vue */
        $this->load->view('templates/header', $data);
        $this->load->view('reservations/afficher_all', $data);
        $this->load->view('templates/footer', $data);
    }

    /* Afficher les réservations une seule à la fois */

    public function afficher($numclient = 0) {
        /* Condition pour vérifier que le client a 
          bien été indiqué dans l'URL */
        if ($numclient == 0) {
            show_404(); //Erreur 404
        }
        /* Données à transmettre à la vue */
        $data['titre'] = "Une réservation";
        $data['numclient'] = $numclient;

        /* Chargement du modèle */
        $this->load->model('Reservations_modele');
        $data['reserv'] = $this->Reservations_modele->getReserv($numclient);

        /* Chargement de la vue */
        $this->load->view('templates/header', $data);
        $this->load->view('reservations/afficher_client', $data);
        $this->load->view('templates/footer', $data);
    }

    public function creation_reservationadmin() {
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->form_validation->set_rules('Date_Arrivee', 'Date_Arrivee', 'required');
        $this->form_validation->set_rules('Date_Depart', 'Date_Depart', 'required');
        $this->form_validation->set_rules('Nb_Personnes', 'Nb_Personnes', 'required');
        $this->form_validation->set_rules('Menage', 'Menage', 'required');
        $this->form_validation->set_rules('idClient', 'idClient', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('form/formCreationReservAdmin');
        } else {
            $this->reservations_modele->set_form4();
            $this->load->view('form/formsuccessadmin');
            $this->load->view('templates/footer');
        }
    }
    
    public function creation_reservationutil() {
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->form_validation->set_rules('Date_Arrivee', 'Date_Arrivee', 'required');
        $this->form_validation->set_rules('Date_Depart', 'Date_Depart', 'required');
        $this->form_validation->set_rules('Nb_Personnes', 'Nb_Personnes', 'required');
        $this->form_validation->set_rules('Menage', 'Menage', 'required');
        $this->form_validation->set_rules('idClient', 'idClient', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('form/formCreationReservUtil');
        } else {
            $this->reservations_modele->set_form();
            $this->load->view('form/formsuccessutil');
            $this->load->view('templates/footer');
        }
    }
    
    public function validation_reservation() {        
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->form_validation->set_rules('idReserv', 'idReserv', 'required');
        $this->form_validation->set_rules('EtatReservation', 'EtatReservation', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('form/formValidReserv');
        } else {
            $this->reservations_modele->set_form1();
            $this->load->view('form/formsuccessadmin');
            $this->load->view('templates/footer');
        }
    }
    
    public function modification_reservation() {        
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');       
        $this->form_validation->set_rules('idReserv', 'idReserv', 'required');
        $this->form_validation->set_rules('Date_Arrivee', 'Date_Arrivee', 'required');
        $this->form_validation->set_rules('Date_Depart', 'Date_Depart', 'required');
        $this->form_validation->set_rules('Nb_Personnes', 'Nb_Personnes', 'required');
        $this->form_validation->set_rules('Menage', 'Menage', 'required');        
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('form/formModifReserv');
        } else {
            $this->reservations_modele->set_form2();
            $this->load->view('form/formsuccessadmin');
            $this->load->view('templates/footer');
        }
    }
    
    public function suppression_reservation() {        
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');   
        $this->form_validation->set_rules('idReserv', 'idReserv', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('form/formSuppReserv');
        } else {
            $this->reservations_modele->set_form3();
            $this->load->view('form/formsuccessadmin');
            $this->load->view('templates/footer');
        }
    }

}
?>



