<?php

Class ConnexionAdmin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Connexionadmin_modele');
        $this->load->library('session');
    }

    public function connexion() {
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->form_validation->set_rules('login', 'login', 'required');
        $this->form_validation->set_rules('mdp', 'mdp', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('form/formConnexionAdmin');
        } else {
            $this->Connexionadmin_modele->set_form1();
            $this->load->view('accueil/afficher_accueiladmin.php');
        }
    }

}
?>



