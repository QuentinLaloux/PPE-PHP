<?php

Class Accueil extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('accueil_modele');
        $this->load->helper('url');
        $this->load->library('session');
    }

    public function afficher_accueil() {

        $data['titre'] = "Accueil";

        /* Chargement de la vue */
        $this->load->view('templates/header', $data);
        $this->load->view('accueil/afficher_accueil', $data);
        $this->load->view('templates/footer', $data);
    }

}
?>
