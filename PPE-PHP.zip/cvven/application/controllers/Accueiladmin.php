<?php

Class Accueiladmin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('accueiladmin_modele');
        $this->load->helper('url');
        $this->load->library('session');
    }

    public function afficher_accueiladmin() {
        
        
        $data['titre'] = "Accueil Administrateur";
        /* Chargement de la vue */
        $this->load->view('templates/header', $data);
        $this->load->view('accueil/afficher_accueiladmin', $data);
        $this->load->view('templates/footer', $data);
    }

}
?>