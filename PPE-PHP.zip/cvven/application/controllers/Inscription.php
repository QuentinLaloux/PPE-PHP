<?php

Class Inscription extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('inscription_modele');
        $this->load->library('session');
    }

    public function inscription() {
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->form_validation->set_rules('login', 'login', 'required');
        $this->form_validation->set_rules('mdp', 'mdp', 'required');
        $this->form_validation->set_rules('nom', 'nom', 'required');
        $this->form_validation->set_rules('prenom', 'prenom', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('form/formInscription');
        } else {
            $this->inscription_modele->set_form2();
            $this->load->view('form/formsuccessutil');
            $this->load->view('templates/footer');
        }
    }

}
?>



