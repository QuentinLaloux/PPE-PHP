<?php

class Calendrier extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
    }
   
    /* Afficher le calendrier */
    public function afficher_calendrier() {

        $data['titre'] = "Calendrier des réservations";

        /* Chargement du modèle */
        $this->load->model('Calendrier_modele');
          
        /* Chargement de la vue */
        $this->load->view('templates/header_calendrier', $data);
        $this->load->view('reservations/afficher_calendrier', $data);
        $this->load->view('templates/footer', $data);

        $prefs = array(
        'show_next_prev'  => TRUE
        );
        /* Chargement du calendrier */
        $this->load->library('calendar', $prefs);
        
    }
}