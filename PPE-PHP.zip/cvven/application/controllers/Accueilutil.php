<?php

Class Accueilutil extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('accueilutil_modele');
        $this->load->helper('url');
        $this->load->library('session');
    }

    public function afficher_accueilutil() {

        $data['titre'] = "Accueil Utilisateur";

        /* Chargement de la vue */
        $this->load->view('templates/header', $data);
        $this->load->view('accueil/afficher_accueilutil', $data);
        $this->load->view('templates/footer', $data);
    }

}
?>