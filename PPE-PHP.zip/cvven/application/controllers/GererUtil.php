<?php

Class GererUtil extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Gererutil_modele');
        $this->load->helper('url_helper');
        $this->load->library('session');
    }

    public function afficher_util() {

        $data['titre'] = "Tout les utilisateurs";

        /* Chargement du modèle */
        $this->load->model('Gererutil_modele');
        $data['util'] = $this->Gererutil_modele->getUtil_all();

        /* Chargement de la vue */
        $this->load->view('templates/header', $data);
        $this->load->view('gererUtil/afficher_util', $data);
        $this->load->view('templates/footer', $data);
    }

    public function ajout_utilisateur() {
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->form_validation->set_rules('login', 'login', 'required');
        $this->form_validation->set_rules('mdp', 'mdp', 'required');
        $this->form_validation->set_rules('nom', 'nom', 'required');
        $this->form_validation->set_rules('prenom', 'prenom', 'required');
        $this->form_validation->set_rules('admin', 'admin', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('form/formAjoutUtil');
        } else {
            $this->Gererutil_modele->set_form();
            $this->load->view('form/formsuccessadmin');
            $this->load->view('templates/footer');
        }
    }

    public function modif_utilisateur() {
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->form_validation->set_rules('idUtil', 'idUtil', 'required');
        $this->form_validation->set_rules('login', 'login', 'required');
        $this->form_validation->set_rules('mdp', 'mdp', 'required');
        $this->form_validation->set_rules('nom', 'nom', 'required');
        $this->form_validation->set_rules('prenom', 'prenom', 'required');
        $this->form_validation->set_rules('admin', 'admin', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('form/formModifUtil');
        } else {
            $this->Gererutil_modele->set_form2();
            $this->load->view('form/formsuccessadmin');
            $this->load->view('templates/footer');
        }
    }

    public function supp_utilisateur() {
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->form_validation->set_rules('idUtil', 'idUtil', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('form/formSuppUtil');
        } else {
            $this->Gererutil_modele->set_form3();
            $this->load->view('form/formsuccessadmin');
            $this->load->view('templates/footer');
        }
    }
    
    public function modif_mdp_utilisateur() {
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->form_validation->set_rules('login', 'login', 'required');
        $this->form_validation->set_rules('mdp', 'mdp', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('form/formModifMdp');
        } else {
            $this->Gererutil_modele->set_form4();
            $this->load->view('form/formsuccessutil');
            $this->load->view('templates/footer');
        }
    }
    

}
